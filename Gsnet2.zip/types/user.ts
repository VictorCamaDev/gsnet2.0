export interface User {
  codigoUsuario?: string
  idUsuario?: string
  correo?: string
  password?: string
  nombres?: string
  loginUsuario?: string
  idPerfil?: number
  nroDocumento?: string
}
