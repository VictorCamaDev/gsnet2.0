"use client";

export default function ProtectedPage() {
  return (
    <div style={{ padding: 32, textAlign: "center", fontSize: 24 }}>
      ¡Bienvenido! Esta es una página protegida y solo puedes verla si tienes sesión activa.
    </div>
  );
}
