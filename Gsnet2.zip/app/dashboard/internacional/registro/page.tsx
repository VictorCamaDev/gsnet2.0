import RegistroInternacional from "@/components/dashboard/internacional/RegistroInternacional";

export default function Page() {
  return <RegistroInternacional />;
}
