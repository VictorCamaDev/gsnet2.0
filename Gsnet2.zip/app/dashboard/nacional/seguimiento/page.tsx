import SeguimientoMuestras from '@/components/dashboard/nacional/SeguimientoMuestras';

export default function Page() {
  return <SeguimientoMuestras />;
}
