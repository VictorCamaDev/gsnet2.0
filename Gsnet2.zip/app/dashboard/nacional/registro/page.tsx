import RegistroNacional from '@/components/dashboard/nacional/RegistroNacional';

export default function Page() {
  return <RegistroNacional />;
}
