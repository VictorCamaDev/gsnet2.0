import SeguimientoNacional from '../../../components/dashboard/nacional/SeguimientoNacional';

export default function Page() {
  return <SeguimientoNacional />;
}
