import React from "react";

const RegistroNacional = () => {
  return (
    <div>
      <h1>Registro Nacional</h1>
      {/* Contenido de registro nacional */}
    </div>
  );
};

export default RegistroNacional;
