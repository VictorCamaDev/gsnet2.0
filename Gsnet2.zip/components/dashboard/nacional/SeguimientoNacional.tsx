import React from "react";

const SeguimientoNacional = () => {
  return (
    <div>
      <h1>Seguimiento Nacional</h1>
      {/* Contenido de seguimiento nacional */}
    </div>
  );
};

export default SeguimientoNacional;
